<?php

/*
 * GR8 Faucet Script Lite
 * https://gr8.cc
 * Edit By 7azemTN
 * https://7azemtn.blogspot.com
 */

## Database settings
$host = 'sql202.epizy.com';
$database = 'epiz_32342424_taheero';
$username = 'epiz_32342424';
$password = 'qrzElVl5I3L';

## Faucet id, this should be changed if you have more than one installation.
$faucetID = 'f1';

## Show Error Messages - Set to false once installion is finished.
$show_errors = true;
